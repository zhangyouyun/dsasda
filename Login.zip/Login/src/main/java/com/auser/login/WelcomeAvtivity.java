package com.auser.login;

import android.app.Activity;
import android.os.Bundle;

import com.example.auser.login.R;

/**
 * Created by Auser on 2015/12/18.
 */
public class WelcomeAvtivity extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
    }
}
