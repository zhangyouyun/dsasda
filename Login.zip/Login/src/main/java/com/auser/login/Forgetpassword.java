package com.auser.login;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;

import com.example.auser.login.R;

/**
 * Created by Auser on 2015/12/18.
 */
public class Forgetpassword extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        setContentView(R.layout.password);


    }
}
